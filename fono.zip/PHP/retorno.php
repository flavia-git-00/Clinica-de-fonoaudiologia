<?php
include_once("conexao.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar se todos os campos do formulário foram enviados
    if (isset($_POST['nome_cliente'], $_POST['data'], $_POST['hora'], $_POST['acao'], $_POST['experiencia'])) {
        // Obter os dados do formulário
        $nome_cliente = $_POST['nome_cliente'];
        $data = $_POST['data'];
        $hora = $_POST['hora'];
        $pq = $_POST['experiencia'];
        $acao = $_POST['acao'];

        // Consulta para obter o código do cliente com base no nome
        $sql_cliente = "SELECT cod_cliente FROM cliente WHERE nome_cliente = ?";
        $stmt_cliente = $conexao->prepare($sql_cliente);
        $stmt_cliente->bind_param("s", $nome_cliente);
        $stmt_cliente->execute();
        $resultado_cliente = $stmt_cliente->get_result();

        if ($resultado_cliente->num_rows > 0) {
            $row_cliente = $resultado_cliente->fetch_assoc();
            $cod_cliente = $row_cliente['cod_cliente'];

            // Inserir um novo registro na tabela retorno
            $sql_inserir_retorno = "INSERT INTO retorno (data_retorno, hora_retorno, motivo_retorno, cod_teste, acao) VALUES (?, ?, ?, ?, ?)";
            $stmt_retorno = $conexao->prepare($sql_inserir_retorno);
            $stmt_retorno->bind_param("ssssi", $data, $hora, $pq, $cod_cliente, $acao);
            // Verificar se o retorno foi inserido com sucesso
            if ($stmt_retorno->affected_rows > 0) {
                // Atualizar a quantidade de aparelhos e baterias no banco de dados
                if ($acao == "comprar") {
                    $sql_atualizar_aparelhos = "UPDATE aparelhos SET qtd_aparelho = qtd_aparelho + 1";
                    $conexao->query($sql_atualizar_aparelhos);

                    $sql_atualizar_baterias = "UPDATE baterias SET qtd_bateria = qtd_bateria + 1";
                    $conexao->query($sql_atualizar_baterias);
                } elseif ($acao == "devolver") {
                    $sql_atualizar_aparelhos = "UPDATE aparelhos SET qtd_aparelho = qtd_aparelho - 1";
                    $conexao->query($sql_atualizar_aparelhos);

                    $sql_atualizar_baterias = "UPDATE baterias SET qtd_bateria = qtd_bateria - 1";
                    $conexao->query($sql_atualizar_baterias);
                }

                echo "Operação concluída com sucesso.";
            } else {
                echo "Erro ao inserir registro na tabela retorno.";
            }

            // Fechar as consultas preparadas
            $stmt_cliente->close();
            $stmt_retorno->close();
        } else {
            echo "Cliente não encontrado.";
        }
    } else {
        echo "Todos os campos do formulário devem ser preenchidos.";
    }
}

// Fechar a conexão com o banco de dados
$conexao->close();
?>

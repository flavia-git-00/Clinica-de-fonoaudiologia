<?php

include_once("conexao.php");

$nome =$_POST['nome_cliente'];
$data_nas=$_POST['data_nas'];
$genero=$_POST['genero'];
$endereco=$_POST['endereco'];
$cpf=$_POST['cpf'];
$email=$_POST['email'];
$telefone=$_POST['celular'];

$insere="INSERT INTO cliente(nome_cliente,data_nas,genero,endereco,cpf,email,telefone) 
         VALUES ('$nome','$data_nas','$genero','$endereco','$cpf','$email','$telefone')";

$resultado =mysqli_query($conexao,$insere);

if($resultado){
    header("Location: ../HTML/cadastroCliente.html");
    exit(); // Certifique-se de que nenhum código adicional seja executado após o redirecionamento
}else{
    echo"algo deu errado na inserção";
}


?>
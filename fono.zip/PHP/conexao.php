<?php
$username='root';
$servername='localhost';
$senha='';
$dbname='fono';

$conexao = mysqli_connect($servername, $username, $senha, $dbname);

// Verificar se a conexão foi bem-sucedida
if ($conexao->connect_error) {
    die("Falha na Conexão com o BD: " . $conexao->connect_error);
   } 

?> 
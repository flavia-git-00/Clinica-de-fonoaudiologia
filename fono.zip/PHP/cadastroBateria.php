<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
    <title>Cadastro Baterias</title>

    <style>
*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Poppins",sans-serif;
    
    
}
.container_poput{
    width: 100%;
    height: 100vh;
    background-color:#1f553e;
    display: flex;
    align-items: center;
    justify-content: center;
}
.btn{
    padding: 10px 60px;
    background-color: #fff;
    border: 0;
    outline: none;
    cursor: pointer;
    font-size: 22px;
    font-weight: 500;
    border-radius: 30px;
}
.poput{
    width: 400px;
    background: #fff;
    border-radius: 6px;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%) scale(1);
    text-align: center;
    padding: 0 30px 30px;
    color: #333;
    visibility: visible;
    transition: transform 0.4s, top 0.4s;
}

.poput img{
    width: 100px;
    margin-top: -50px;
    border-radius: 50%;
    box-shadow: 0 2px 5px rgba(0, 0,0, 0.2);
}
.poput h2{
    font-size: 38px;
    font-weight: 500;
    margin: 30px 0 10px;

}
.poput button{
    width: 100%;
    margin-top: 50px;
    padding: 10px 0;
    background-color:#6fd649 ;
    color: #fff;
    border: 0;
    outline: none;
    font-size: 18px;
    border-radius: 4px;
    cursor: pointer;
    box-shadow: 0 2px 5px rgba(0, 0,0, 0.2);
}
.poput button:hover{
    background-color:#49dc13 ;
}


    </style>
</head>
<body>
   <?php
   include_once('conexao.php');

   $tipo = $_POST['tipo'];
   $modelo = $_POST ['modelo'];
   $duracao = $_POST ['duracao'];
   $preco = $_POST ['preco'];
   $qtd = $_POST ['quantidade'];

  
   $insere = mysqli_query($conexao, "INSERT INTO baterias (tipo_bateria, modelo_bateria, duracao_bateria, preco_bateria, qtd_bateria)
    VALUES ('$tipo', '$modelo', '$duracao', '$preco', '$qtd')") or die(mysqli_error($conexao));
 
 if ($insere) {
    echo '<div class="container_poput">';
    echo '<div class="poput" id="poput">';
    echo '    <img src="../imgs/poput.png" alt="">';
    echo '    <h2>Bateria Cadastrada!</h2>';
    echo '    <p>os dados foram adicionados ao banco.</p>';
    echo '    <button type="button" onclick="closePoput()">OK</button>';
    echo '</div>';
     echo '</div>';
    
} else {
    echo "Erro ao inserir os dados: " . mysqli_error($conexao);
}
   
   ?>
</body>
</html>

<script>
    function closePoput() {
        let poput = document.getElementById("poput");
        setTimeout(function() {
            window.location.href = "../HTML/produto.html";
        }, 500); // Atraso de 500ms para permitir que a animação de fechamento ocorra
    }
</script>
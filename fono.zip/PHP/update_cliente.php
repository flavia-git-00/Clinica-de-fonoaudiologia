<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atualização</title>
<style>

@import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');

    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Poppins",sans-serif;
        
        
    }
    .container_poput{
        width: 100%;
        height: 100vh;
        background-color:#1f553e;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .btn{
        padding: 10px 60px;
        background-color: #fff;
        border: 0;
        outline: none;
        cursor: pointer;
        font-size: 22px;
        font-weight: 500;
        border-radius: 30px;
    }
    .poput{
        width: 400px;
        background: #fff;
        border-radius: 6px;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%,-50%) scale(1);
        text-align: center;
        padding: 0 30px 30px;
        color: #333;
        visibility: visible;
        transition: transform 0.4s, top 0.4s;
    }

    .poput img{
        width: 100px;
        margin-top: -50px;
        border-radius: 50%;
        box-shadow: 0 2px 5px rgba(0, 0,0, 0.2);
    }
    .poput h2{
        font-size: 38px;
        font-weight: 500;
        margin: 30px 0 10px;

    }
    .poput button{
        width: 100%;
        margin-top: 50px;
        padding: 10px 0;
        background-color:#6fd649 ;
        color: #fff;
        border: 0;
        outline: none;
        font-size: 18px;
        border-radius: 4px;
        cursor: pointer;
        box-shadow: 0 2px 5px rgba(0, 0,0, 0.2);
    }
    .poput button:hover{
        background-color:#49dc13 ;
    }
    /* FIM CODIGO POPUT */
</style>

</head>
<body>
    
<?php

include_once("conexao.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
// Obter os dados do formulário
$cod_cliente=$_POST['cod_cliente'];
$nome_cliente = $_POST['nome_cliente'];
$data_nas = $_POST['data_nas'];
$telefone=$_POST['celular'];
$email = $_POST['email'];
$cpf = $_POST['cpf'];
$endereco = $_POST['endereco'];
$genero = $_POST['genero'];

// SQL para atualizar os dados do cliente
$sql = "UPDATE cliente SET 
        nome_cliente='$nome_cliente',  
        data_nas='$data_nas', 
        genero='$genero', 
        endereco='$endereco', 
        cpf='$cpf', 
        email='$email',
        telefone='$telefone'
        WHERE cod_cliente ='$cod_cliente'";

        $result= mysqli_query($conexao,$sql);

if ($result) {
    echo '<div class="container_poput">';
            echo '<div class="poput" id="poput">';
            echo '    <img src="../imgs/poput.png" alt="">';
            echo '    <h2>Paciente Atualizado!</h2>';
            echo '    <p>Os dados já foram modificados no banco.</p>';
            echo '    <button type="button" onclick="closePoput()">OK</button>';
            echo '</div>';
    echo '</div>';

            echo '<script>
                function closePoput() {
                    let poput = document.getElementById("poput");
                    setTimeout(function() {
                        window.location.href = "../HTML/atualizarC.php";
                    }, 500); // Atraso de 500ms para permitir que a animação de fechamento ocorra
                }
            </script>';
        exit();
} else {
    echo "Erro ao atualizar os dados: " . $conexao->error;
            exit();
}
   }
?>


</body>
</html>
CREATE DATABASE fono;

CREATE table cliente(

cod_cliente INT PRIMARY KEY AUTO_INCREMENT,
nome_cliente VARCHAR(60),
data_nas DATE,
genero VARCHAR(25),
endereco Varchar(255),
cpf char(14),
email Varchar(64),
telefone VARCHAR(20)

);

CREATE table baterias(

cod_bateria INT PRIMARY KEY AUTO_INCREMENT,
tipo_bateria VARCHAR(60),
modelo_bateria VARCHAR(60),
duracao_bateria VARCHAR(10),
preco_bateria DECIMAL(10,2),
qtd_bateria INT(9)

);

CREATE table aparelhos(

cod_aparelho INT PRIMARY KEY AUTO_INCREMENT,
modelo_aparelho VARCHAR(60),
fabricante_aparelho VARCHAR(60),
garantia_aparelho VARCHAR(10),
preco_aparelho DECIMAL(10,2),
qtd_aparelho INT(9),
data_aparelho DATE DEFAULT (CURRENT_DATE)

);


CREATE table atendimento(
cod_atendimento INT PRIMARY KEY AUTO_INCREMENT,
data_atendimento DATE,
hora_atendimento TIME,
observacao_atendimento VARCHAR(100),
cod_cliente int,
FOREIGN KEY (cod_cliente) REFERENCES cliente (cod_cliente) ON DELETE CASCADE
);

CREATE TABLE teste (
    cod_teste INT PRIMARY KEY AUTO_INCREMENT,
    data_retirada DATE DEFAULT CURRENT_DATE,
    hora_retirada TIME DEFAULT CURRENT_TIME,
    data_devolucao DATE,
    hora_devolucao TIME,
    observacao_teste VARCHAR(100),
    qtd_teste INT (9),
    cod_cliente INT,
    cod_aparelho INT,
    FOREIGN KEY (cod_cliente) REFERENCES cliente (cod_cliente) ON DELETE CASCADE,
    FOREIGN KEY (cod_aparelho) REFERENCES aparelhos (cod_aparelho) ON DELETE CASCADE
);

CREATE table retorno(
cod_retorno INT PRIMARY KEY AUTO_INCREMENT,
data_retorno DATE,
hora_retorno TIME,
motivo_retorno VARCHAR(100),
cod_cliente int,
FOREIGN KEY (cod_cliente) REFERENCES teste (cod_cliente) ON DELETE CASCADE

);

CREATE table devolucao(
cod_devolucao INT PRIMARY KEY AUTO_INCREMENT,
data_devolucao DATE,
hora_devolucao TIME,
condicao_devolucao VARCHAR(100),
qtd_devolucao INT(9),
cod_cliente INT,
cod_aparelho INT,
FOREIGN KEY (cod_cliente) REFERENCES teste (cod_cliente) ON DELETE CASCADE,
FOREIGN KEY (cod_aparelho) REFERENCES teste (cod_aparelho) ON DELETE CASCADE
);

CREATE table pagamento(
cod_pagamento INT PRIMARY KEY AUTO_INCREMENT,
valor_pagamento DECIMAL(10,2),
forma_pagamento VARCHAR(20),
data_pagamento DATE DEFAULT (CURRENT_DATE),
hora_pagamento TIME DEFAULT (CURRENT_TIME),
qtd_pagamento int(9),
cod_aparelho int,
cod_cliente int,
FOREIGN KEY (cod_cliente) REFERENCES cliente (cod_cliente) ON DELETE CASCADE,
FOREIGN KEY (cod_aparelho) REFERENCES aparelhos  (cod_aparelho) ON DELETE CASCADE

);

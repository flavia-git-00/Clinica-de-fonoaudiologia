// FUNÇÃO PARA A BARRA DE PROGRESSO E ALTERAÇÃO DE VISIBILIDADE DOS ELEMENTOS
function progress(botao) {
    // Obtém todos os elementos <li> com a classe 'step-wizard-item'
    var itens = document.querySelectorAll('.step-wizard-item');
    var container = document.querySelector('.container');
    var containerAtendimento = document.querySelector('.containerAtendimento');
    var contentProduto = document.querySelector('.content-produto');
    var col_teste_compra = document.querySelector('.col-2');
    var containerPagamento = document.querySelector('.containerPagamento');

    // Encontra o índice do item que atualmente tem a classe 'current-item'
    var currentIndex = Array.from(itens).findIndex(function(item) {
        return item.classList.contains('current-item');
    });
    
    // Remove a classe 'current-item' do item atual
    if (currentIndex !== -1) {
        itens[currentIndex].classList.remove('current-item');
    }
    
    // Adiciona a classe 'current-item' ao próximo item, se existir
    var nextIndex = currentIndex + 1;
    if (nextIndex < itens.length) {
        itens[nextIndex].classList.add('current-item');
    }

     if (container.style.display !== "none") {

        container.style.display = "none";
        containerAtendimento.style.display = "flex";
        contentProduto.style.display = "none";
        col_teste_compra.style.display="none";
        containerPagamento.style.display="none";
     
    } else if (containerAtendimento.style.display !== "none") {
        containerAtendimento.style.display = "none";
        contentProduto.style.display = "flex";
    } else if(contentProduto.style.display !== "none"){
        contentProduto.style.display = "none";
        col_teste_compra.style.display="flex";
        containerPagamento.style.display="none"
    }
   
}

function end_atendimento(fim){
    var itens = document.querySelectorAll('.step-wizard-item');
      // Encontra o índice do item que atualmente tem a classe 'current-item'
      var currentIndex = Array.from(itens).findIndex(function(item) {
        return item.classList.contains('current-item');
    });
    
    // Remove a classe 'current-item' do item atual
    if (currentIndex !== -1) {
        itens[currentIndex].classList.remove('current-item');
    }
    // Adiciona a classe 'current-item' ao próximo item, se existir
    var nextIndex = currentIndex + 3;
    if (nextIndex < itens.length) {
        itens[nextIndex].classList.add('current-item');
    }
}
// END
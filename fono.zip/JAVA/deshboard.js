// add hovered class to selected list item
let list = document.querySelectorAll(".navigation li");

function activeLink() {
  list.forEach((item) => {
    item.classList.remove("hovered");
  });
  this.classList.add("hovered");
}

list.forEach((item) => item.addEventListener("mouseover", activeLink));

// Menu Toggle
let toggle = document.querySelector(".toggle");
let navigation = document.querySelector(".navigation");
let main = document.querySelector(".main");

toggle.onclick = function () {
  navigation.classList.toggle("active");
  main.classList.toggle("active");
};

function alternar(divId) {
  console.log("cliquei");
  
  let DivEstoque = document.getElementById("estoque_todo");
  let DivRelatorio = document.getElementById("relatorio_todo");
  let Divcliente = document.getElementById("cliente_todo");
  let Divhistorico = document.getElementById("historico_todo");
  let Divajuda= document.getElementById("ajuda_todo");
  let Divconfig= document.getElementById("config_todo");

  // Esconder todas as divs
  DivEstoque.style.display = "none";
  DivRelatorio.style.display = "none";
  Divcliente.style.display = "none";
  Divhistorico.style.display = "none";

  // Mostrar apenas a div correspondente ao id passado
  if (divId === "estoque_todo") {
      DivEstoque.style.display = "grid";
  } else if (divId === "relatorio_todo") {
      DivRelatorio.style.display = "grid";
  } else if (divId === "cliente_todo") {
      Divcliente.style.display = "grid";
  } else if (divId === "historico_todo") {
      Divhistorico.style.display = "grid";
  } else if (divId === "ajuda_todo") {
    Divhistorico.style.display = "grid";
   }else if (divId === "config_todo") {
    Divhistorico.style.display = "grid";
}
}


// FUNÇÃO PARA A PESSOA VISUALIZAR O PRODUTO QUE DESEJA COMPRAR OS TESTAR
function handleCheckboxChange(checkbox) {

    var otherCheckboxId = checkbox.id === "additionalCheckbox" ? "adicionarBotao" : "additionalCheckbox";
    var otherCheckbox = document.getElementById(otherCheckboxId);
    if (checkbox.checked) {
        otherCheckbox.checked = false;
    }

    const additionalInputs = document.getElementById('additionalInputs');
    if (checkbox.checked) {
        additionalInputs.style.display = 'flex';
    } else {
        additionalInputs.style.display = 'none';
    }

    var submit = document.getElementById('divsubmit');
    if (submit) {
   submit.style.display = "none";
}

}

// FUNÇÃO PARA FINALIZAR O ATENDIMENTO CASO A PESSOA NÃO DESEJE NENHUM PRODUTO
function finalizar(checkbox){

handleCheckboxChange(checkbox);

var additionalInputs = document.getElementById("additionalInputs");
    if (additionalInputs) {
        additionalInputs.style.display = "none";
    }

const submit = document.getElementById('divsubmit');
    if(checkbox.checked){
        submit.style.display='flex';
    }else{
        submit.style.display='none';
    }
}

// FUNÇÃO PARA ALTERAR VISIBILIDADE ELEMENTOS NA TELA CASO A PESSOA QUEIRA COMPRAR UM PRODUTO
function caixa_de_selecao(checkbox){
    var otherCheckboxId = checkbox.id === "caixa1" ? "caixa2" : "caixa1";
    var otherCheckbox = document.getElementById(otherCheckboxId);
    if (checkbox.checked) {
        otherCheckbox.checked = false;
    }

    const containerPagamento = document.getElementById('containerPagamento');

    if(checkbox.checked){
        containerPagamento.style.display ="flex";  
    }else{
        containerPagamento.style.display="none";
    }

    var containerTeste = document.getElementById('containerTeste');

    if(containerTeste){
        containerTeste.style.display ="none";
    }else{
        containerTeste.style.display="flex";
    }
}

// FUNÇÃO PARA ALTERAR VISIBILIDADE ELEMENTOS NA TELA CASO A PESSOA QUEIRA TESTAR UM PRODUTO
function caixa_de_selecao_teste(checkbox){

    caixa_de_selecao(checkbox);

    var containerPagamento = document.getElementById('containerPagamento');
    
    if(containerPagamento){
        containerPagamento.style.display ="none";
    }

    var containerTeste = document.getElementById('containerTeste');
    if(checkbox.checked){
        containerTeste.style.display="flex";
    }else{
        containerTeste.style.display ="none";
    }
}


// MULTIPLICAR O VALOR DO PRODUTO PELO PREÇO DO BANCO
function aumentar() {
    let select = document.getElementById("select-aparelho");
    let selectedOption = select.options[select.selectedIndex];
    let selectedPrice = parseFloat(selectedOption.getAttribute("data-preco"));
    let contadorInput = document.getElementById('contadorInput');
    let contador = parseInt(contadorInput.value);
    contador++;
    contadorInput.value = contador;
    let resultado = selectedPrice * contador;
    let valor = document.getElementById('valor');
    valor.textContent = `R$${resultado.toFixed(2).replace('.', ',')}`;
    document.getElementById('valor_pagamento').value = resultado;
}

function diminuir() {
    let select = document.getElementById("select-aparelho");
    let selectedOption = select.options[select.selectedIndex];
    let selectedPrice = parseFloat(selectedOption.getAttribute("data-preco"));
    let contadorInput = document.getElementById('contadorInput');
    let contador = parseInt(contadorInput.value);
    if (contador > 1) {
        contador--;
        contadorInput.value = contador;
        let resultado = selectedPrice * contador;
        let valor = document.getElementById('valor');
        valor.textContent = `R$${resultado.toFixed(2).replace('.', ',')}`;
        document.getElementById('valor_pagamento').value = resultado;
    }
}

function updateValue() {
    let select = document.getElementById("select-aparelho");
    let selectedOption = select.options[select.selectedIndex];
    let selectedPrice = parseFloat(selectedOption.getAttribute("data-preco"));
    let contadorInput = document.getElementById('contadorInput');
    let contador = parseInt(contadorInput.value);
    let resultado = selectedPrice * contador;
    let valor = document.getElementById('valor');
    valor.textContent = `R$${resultado.toFixed(2).replace('.', ',')}`;
    valor.dataset.original = selectedPrice;
    document.getElementById('valor_pagamento').value = resultado;
}
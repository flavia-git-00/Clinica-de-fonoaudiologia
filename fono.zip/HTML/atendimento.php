
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <title>Atendimento</title>

<style>
/* STYLE PARA O POPUT */
*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Poppins",sans-serif;
}
.container{
    width: 100%;
    height: 100vh;
    background-color: #3a9d7d;
    display: flex;
    align-items: center;
    justify-content: center;
}
.btn{
    padding: 10px 60px;
    background-color: #fff;
    border: 0;
    outline: none;
    cursor: pointer;
    font-size: 22px;
    font-weight: 500;
    border-radius: 30px;
}
.poput{
    width: 400px;
    background: #fff;
    border-radius: 6px;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%) scale(1);
    text-align: center;
    padding: 0 30px 30px;
    color: #333;
    visibility: visible;
    transition: transform 0.4s, top 0.4s;
}
.close-poput{
    visibility: hidden;
    top: 50%;
    transform: translate(-50%,-50%) scale(1);
    

}
.poput img{
    width: 100px;
    margin-top: -50px;
    border-radius: 50%;
    box-shadow: 0 2px 5px rgba(0, 0,0, 0.2);
}
.poput h2{
    font-size: 38px;
    font-weight: 500;
    margin: 30px 0 10px;

}.poput button{
    width: 100%;
    margin-top: 50px;
    padding: 10px 0;
    background-color:#6fd649 ;
    color: #fff;
    border: 0;
    outline: none;
    font-size: 18px;
    border-radius: 4px;
    cursor: pointer;
    box-shadow: 0 2px 5px rgba(0, 0,0, 0.2);


}

.icons {
  position: absolute; /* Define o posicionamento absoluto */
  top: 10px; /* Define a distância do topo */
  left: 10px; /* Define a distância da esquerda */
  color: #ffffff;
  text-decoration: none;
  font-size: 40px; /* Define o tamanho do ícone */
  cursor: pointer;
}
.bi-arrow-return-left{
  color: #ffffff;
}
.bi-arrow-return-left:hover{
  /*cor de fundo quando  o mouse passa por cima*/
  background-color: #3a9d7d;
  color:#287c62;
}
/* END POPUT */

 </style>
</head>
<body>
    <!-- O PHP ESTA INTERAGINDO COM OS VALUES DO BUTTONS SUBMIT PARA INSERÇÃO DOS DADOS CORRETOS NO BANCO -->
<?php

 include_once("../PHP/conexao.php");
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
// SE A PESSOA FINALIZAR O ATENDIMENTO E NAO LEVAR NENHUM PRODUTO
    if (isset($_POST['submit_atendimento'])) {

    $codigo_cliente = $_POST['paciente-select'];
    $hora_atendimento = $_POST['hora_atendimento'];
    $data_atendimento = $_POST['data_atendimento'];
    $obs_atendimento = $_POST['obs_atendimento'];
    
    $insere = "INSERT INTO atendimento (data_atendimento, hora_atendimento, observacao_atendimento, cod_cliente) 
    VALUES ('$data_atendimento', '$hora_atendimento', '$obs_atendimento', '$codigo_cliente')";

            if (mysqli_query($conexao, $insere)) {
                echo '<div class="icons">';
                echo '    <a href="atendimento.php" class="back-button"><i class="bi bi-arrow-return-left"></i></a>';
                echo '</div>';

                echo '<div class="container">';
                echo '    <div class="poput" id="poput">';
                echo '        <img src="../imgs/poput.png" alt="">';
                echo '        <h2>Atendimento Finalizado</h2>';
                echo '        <p>Foi um prazer atendê-lo! Volte sempre que precisar.</p>';
                echo '        <button type="button" onclick="closePoput()">OK</button>';
                echo '    </div>';
                echo '</div>';
                echo '<script>';
                echo '    let poput = document.getElementById("poput");';
                echo '    function closePoput() {';
                echo '        poput.classList.add("close-poput");';
                echo '        setTimeout(function() {';
                echo '            window.location.href = "atendimento.php";';
                echo '        }, 500);'; // Atraso de 500ms para permitir que a animação de fechamento ocorra
                echo '    }';
                echo '</script>';
            } else {

                echo '<script>';
                echo 'alert("[ERRO!] Atendimento não finalizado! ' . mysqli_error($conexao) . '");';
                echo 'window.location.href = "atendimento.php";'; // Redirecionamento em JavaScript
                echo '</script>';
                exit();
            }

    } 

    // END SUBMIT ATENDIMENTO

// SE O CLIENTE LEVAR O PRODUTO PARA TESTE
    if (isset($_POST['submit_teste'])) {

        $cod_cliente = $_POST['paciente-select'];
        $data_devolucao = $_POST['data_teste'];
        $hora_devolucao = $_POST['hora_teste'];
        $obs_teste = $_POST['obs_teste'];
        $cod_aparelho = $_POST['select-aparelho'];
        $qtd_testada = $_POST['qtd'];

        $insere = mysqli_query($conexao, "INSERT INTO teste (data_devolucao,hora_devolucao,observacao_teste,qtd_teste,cod_cliente,cod_aparelho)
        VALUES ('$data_devolucao','$hora_devolucao','$obs_teste','$qtd_testada','$cod_cliente','$cod_aparelho')") or die(mysqli_error($conexao));

    if ($insere) {
    // Recupere a quantidade atual de aparelhos devolvidos
    $query_aparelho = mysqli_query($conexao, "SELECT qtd_aparelho FROM aparelhos WHERE cod_aparelho = '$cod_aparelho'");
    $row_aparelho = mysqli_fetch_assoc($query_aparelho);
    $quantidade_atual = $row_aparelho['qtd_aparelho'];

    // Adicione a quantidade devolvida atual à quantidade atual
    $nova_quantidade = $quantidade_atual - $qtd_testada;

    // Atualize o registro na tabela aparelhos com a nova quantidade
    $atualiza_aparelho = mysqli_query($conexao, "UPDATE aparelhos SET qtd_aparelho = '$nova_quantidade' WHERE cod_aparelho = '$cod_aparelho'");
    
    if ($atualiza_aparelho) {
        echo '<div class="container">';
        echo '    <div class="poput" id="poput">';
        echo '        <img src="../imgs/poput.png" alt="">';
        echo '        <h2>Teste Finalizado</h2>';
        echo '        <p>Foi um prazer atendê-lo! Volte sempre que precisar.</p>';
        echo '        <button type="button" onclick="closePoput()">OK</button>';
        echo '    </div>';
        echo '</div>';
        echo '<script>';
        echo '    let poput = document.getElementById("poput");';
        echo '    function closePoput() {';
        echo '        poput.classList.add("close-poput");';
        echo '        setTimeout(function() {';
        echo '            window.location.href = "atendimento.php";';
        echo '        }, 500);'; // Atraso de 500ms para permitir que a animação de fechamento ocorra
        echo '    }';
        echo '</script>';
    } else {
        // Se a atualização falhar
        echo "Erro ao atualizar a quantidade de aparelhos devolvidos!";
        }
    } else {
        // Se a inserção falhar
        echo "Erro ao registrar a devolução!";
    }
  }
}
// END SUBMIT TESTE

// SE O CLIENTE DESEJAR COMPRAR O PRODUTO
    if (isset($_POST['submit_pagamento'])) {

        $cod_cliente = $_POST['paciente-select'];
        $cod_aparelho = $_POST['select-aparelho'];
        $metodo = $_POST['payment'];
        $valor = $_POST['valor_pagamento'];
        $qtd =$_POST['qtd'];

        $insere = mysqli_query($conexao, "INSERT INTO pagamento (valor_pagamento,forma_pagamento,qtd_pagamento,cod_aparelho,cod_cliente)
        VALUES ('$valor', '$metodo','$qtd', '$cod_aparelho','$cod_cliente')") or die(mysqli_error($conexao));
 
 if ($insere) {
    // Recupere a quantidade atual de aparelhos devolvidos
    $query_aparelho = mysqli_query($conexao, "SELECT qtd_aparelho FROM aparelhos WHERE cod_aparelho = '$cod_aparelho'");
    $row_aparelho = mysqli_fetch_assoc($query_aparelho);
    $quantidade_atual = $row_aparelho['qtd_aparelho'];

    // Adicione a quantidade devolvida atual à quantidade atual
    $nova_quantidade = $quantidade_atual - $qtd;

   
    $atualiza_aparelho = mysqli_query($conexao, "UPDATE aparelhos SET qtd_aparelho = '$nova_quantidade' WHERE cod_aparelho = '$cod_aparelho'");

    if ($atualiza_aparelho) {
        echo '<div class="container">';
        echo '    <div class="poput" id="poput">';
        echo '        <img src="../imgs/poput.png" alt="">';
        echo '        <h2>Pagamento Finalizado!</h2>';
        echo '        <p>Foi um prazer atendê-lo! Volte sempre que precisar.</p>';
        echo '        <button type="button" onclick="closePoput()">OK</button>';
        echo '    </div>';
        echo '</div>';
        echo '<script>';
        echo '    let poput = document.getElementById("poput");';
        echo '    function closePoput() {';
        echo '        poput.classList.add("close-poput");';
        echo '        setTimeout(function() {';
        echo '            window.location.href = "atendimento.php";';
        echo '        }, 500);'; // Atraso de 500ms para permitir que a animação de fechamento ocorra
        echo '    }';
        echo '</script>';
    } else {
        // Se a atualização falhar
        echo "Erro ao atualizar a quantidade de aparelhos devolvidos!";
        }
    } else {
        // Se a inserção falhar
        echo "Erro ao registrar a devolução!";
  }
}
// END SUBMIT PAGAMENTO
?>

</body>
</html>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../CSS/atendimento.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <title>Atendimento</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

    <div class = "icons" >
        <a href="index.html" class="back-button"><i class="bi bi-arrow-return-left"></i> </a>
    </div>
                <div class="br"></div>
      
        
<!-- BARRA DE PROGRESSO -->
        <section class="step-wizard">
            <ul class="step-wizard-list">
                <li class="step-wizard-item current-item">
                    <span class="progress-count">1</span>
                    <span class="progress-label">Cliente</span>
                </li>

                <li class="step-wizard-item">
                    <span class="progress-count" >2</span>
                    <span class="progress-label">Dados Atendimento</span>
                </li>

              
                <li class="step-wizard-item ">
                    <span class="progress-count">3</span>
                    <span class="progress-label">Teste/Compra</span>
                </li>

                <li class="step-wizard-item ">
                    <span class="progress-count">4</span>
                    <span class="progress-label">Finalizar</span>
                </li>

                <li class="step-wizard-item" style="display:none">
                    <span class="progress-count">4</span>
                    <span class="progress-label">Teste/Compra</span>
                </li>
            </ul>
        </section>
<!-- END -->

<!-- FORM ACTION VAZIO ENVIANDO OS DADOS PARA O MESMO O PHP NO TOPO DO CODIGO -->
   
<form action="" method="post">
<!-- CLIENTE -->
        <div class="container">
            <div class="box">
                  
                <h1>Selecione o Paciente</h1>
                
            <label for="Paciente" class="paciente-label">Nome completo:</label>
            <select class="paciente-select" name="paciente-select" id="">

            <?php
                include_once("../PHP/conexao.php");

                $sql = "SELECT cod_cliente,nome_cliente FROM cliente";
                $result = mysqli_query($conexao,$sql); 

                if($result->num_rows >0){

                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<option value="' . $row['cod_cliente'] . '">' . $row['nome_cliente'] . '</option>';
                }
            }
        ?>
        
            </select>
                <button type="button" class="paciente-button" onclick="progress(this)">Próximo</button>
            </div>
        </div>
 <!-- END -->

<!-- DADOS DO ATENDIMENTO -->
        <div class="containerAtendimento" style="display: none;">
            <div class="box_atendimento">
                <h1>Preencha os dados do atendimento</h1>
                
                <div class="data-hora-row">
                    <div>
                        <label for="Data_atendimento" class="label_atendimento">Data:</label >
                        <input type="date" name="data_atendimento" class="InputData" required>
                    </div>
                    <div>
                        <label for="hora_atendimento" class="label_atendimento">Hora:</label>
                        <input type="time" name="hora_atendimento" class="InputHora" required>
                    </div>
                </div>

        <div class="obs-content">
            <div class="justify-content">
                <label for="observacao" class="label_observacao">Observação:</label>
                <textarea name="obs_atendimento" class="obs_atendimento"></textarea>
            </div>
        </div>

           <div class="content-button">
                <button type="button" class="atendimento-button" onclick="progress(this)">Próximo</button>
            </div>

            </div>
        </div>
<!-- END -->
        
<!--    SELECIONAR COMPRAR OU TESTAR DE PRODUTOS    -->
<div class="content-produto" style="display: none;">
    <div class="col-1">
        <label class="frase" for="additionalCheckbox">Deseja comprar ou testar algum produto?</label><br><br>
       
        <div class="resposta">
            <label for="extraInfo1">Sim</label>
            <input type="checkbox" id="additionalCheckbox" name="additionalCheckbox" onchange="handleCheckboxChange(this)">
            <label for="extraInfo2">Não</label>
            <input type="checkbox" id="adicionarBotao" name="extraInfo2" onchange="finalizar(this)"><br><br>
        </div>
    </div>
<br>

 <!-- ID dditionalInputs UTILIZADA EM scriptProduto.js PARA ALTERAR A VISIBILIDADE DOS ELEMENTOS -->
    <div class="selecao" id="additionalInputs" style="display: none">
        
        <div class="img-prod">
            <img class="img-fluid" src="../imgAparelhos/aparelho-removebg-preview.png">
         </div>
    
         <div class="containerProduto">
            <br>

    <label for="">Selecione o produto:</label>
        
    <select class="select" id="select-aparelho" name="select-aparelho" onchange="mudarValor(event)">
        <?php
            include_once("../PHP/conexao.php");
            $sql = "SELECT cod_aparelho, modelo_aparelho, preco_aparelho FROM aparelhos";
            $result = mysqli_query($conexao, $sql);
            if ($result->num_rows > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<option value="' . $row['cod_aparelho'] . '" data-preco="' . $row['preco_aparelho'] . '">' . $row['modelo_aparelho'] . '</option>';
                }
            }
        ?>
    </select> 
<br>
                <p class="nomeProduto">Aparelho Auditivo Digital Oticon Opn S1</p>
                
                <span class="valor" id="valor">R$00,00</span>
                <input type="hidden" name="valor_pagamento" id="valor_pagamento" value="0"> <!-- Valor inicial -->

            <script>
                function mudarValor(event) {
                    var select = event.target;
                    var selectedOption = select.options[select.selectedIndex];
                    var selectedPrice = selectedOption.getAttribute("data-preco");
                    var pElement = document.getElementById("valor");
                    pElement.textContent = "R$" + selectedPrice;
                }
            </script>
               
                <p class="fornecedor">por:teclogic.com</p>

                <div class="productQuantity">
    
                    <span class="productQuantity__cta minus"  onclick="diminuir()" data-type="sub">
                        <span class="delete-img">
                            <span class="plus-img">-</span>
                        </span>
                    </span>
                    <input type="text" class="productQuantity__value" name="qtd" id="contadorInput" value="1"  onchange="updateValue()">
                        <span data-type="add" class="productQuantity__cta plus " onclick="aumentar()">
                            <span class="plus-img">+</span>
                        </span>
    
                </div>
                <input type="hidden" id="hidden-value" name="original_value">
                    <button class="button" type="button" onclick="progress(this)">Próximo</button>
                   
                </div>
    </div>

<!-- CASO A PESSOA NÃO QUEIRA TESTAR O COMPRAR ALGUM PRODUTO NO ATENDIMENTO O BOTÃO SE TORNA VISIVEL scriptProduto.js  -->
        <div class="finalizar" id="divsubmit" style="display: none;" >
            <input class="buttonFinalizar" name="submit_atendimento" type="submit" value="Finalizar Atendimento" onclick="end_atendimento(this)" >
        </div>
<!-- END -->

</div>
   


<!-- FUNÇÃO ONCHANGE PARA APLICAR MUDANÇAS NA VISIBILIDADE DOS ELEMENTOS EM DETERMINADA AÇÃO DO USUARIO -->

    <div class="col-2" style="display: none;">
        <label class="frase-teste" for="additionalCheckbox">Selecione uma das opções?</label><br><br>
       
        <div class="teste-compra">
            <label for="extraInfo1">COMPRAR</label>
            <input type="checkbox" id="caixa1" name="additionalCheckbox" onchange="caixa_de_selecao(this)">
            <label for="extraInfo2">TESTAR</label>
            <input type="checkbox" id="caixa2" name="extraInfo2" onchange="caixa_de_selecao_teste(this)"><br><br>
        </div>
    </div>

    <!-- CONTENT DO PAGAMENTO -->
    <div class="containerPagamento" id="containerPagamento" style="display: none;">

        <div class="container_pag_2">
            <div class="title">
                <h4>selecione <span style="color: #6064b6">metodo </span> pagamento</h4>
            </div>
        
        <div class="InputRadio">
            <input type="radio" name="payment" id="visa" value="visa">
            <input type="radio" name="payment" id="mastercard" value="MasterCard">
            <input type="radio" name="payment" id="paypal" value="Paypal">
            <input type="radio" name="payment" id="AMEX" value="Amex">
        </div>
        
        
                <div class="category">
                    <label for="visa" class="visaMethod">
                        <div class="imgName">
                            <div class="imgContainer visa">
                                <img src="https://i.imgur.com/556PdMp.png" alt="">
                            </div>
                            <br>
                            <span class="name">cartão de credito</span>
                        </div>
                        <span class="check"><i class="fas fa-check-circle" style="color: #6064b6;"></i></span>
                    </label>
        
                    <label for="mastercard" class="mastercardMethod"> 
        
                        <div class="imgName">
                            <div class="imgContainer mastercard">
                                <img src="https://i.imgur.com/rHbGbtQ.png" alt="">
                            </div>
                            <span class="name">Cartão de debito</span>
                        </div>
                        <span class="check"><i class="fas fa-check-circle" style="color: #6064b6;"></i></span>
        
                    </label>
        
                    <label for="paypal" class="paypalMethod">   <div class="imgName">
                        <div class="imgContainer paypal">
                            <img src="https://i.imgur.com/jw7TINo.png" alt="">
                        </div>
                        <span class="name">dinheiro</span>
                    </div>
                    <span class="check"><i class="fas fa-check-circle" style="color: #6064b6;"></i></span>
                </label>
             
                    <label for="AMEX" class="amexMethod">  <div class="imgName">
                        <div class="imgContainer AMEX">
                            <img src="https://i.imgur.com/3Y5q5vd.png" alt="">
                        </div>
                        <span class="name">pix</span>
                    </div>
                    <span class="check"><i class="fas fa-check-circle" style="color: #6064b6;"></i></span>
                </label>
              

        </div>
              
        <div class="content-pag_button">
            <input class="atendimento-button" name="submit_pagamento" type="submit" value="Finalizar" onclick="end_atendimento(this)" >
        </div>
            
        </div>
    </div>
 <!-- END  COMPRAR PRODUTO -->

  <!-- TESTE DE PRODUTOS A PARTIR DELE O CLIENTE PODE DAR RETORNO A CLINICA -->
    <div class="containerTeste" id="containerTeste" style="display: none;">
        <div class="box_teste">
            <h1>Teste de aparelhos auditivos</h1>
            <label for="label-teste" class="label-teste">Selecione a data e a hora da devolução:</label>

            <div class="data-hora-row">
                <div>
                    <label for="Data_teste" class="label_atendimento">Data:</label>
                    <input type="date" name="data_teste" class="InputData">
                </div>
                <div>
                    <label for="hora_teste" class="label_atendimento">Hora:</label>
                    <input type="time" name="hora_teste" class="InputHora">
                </div>
            </div>

    <div class="obs-content">
        <div class="justify-content">
            <label for="observacao_teste" class="label_observacao">Observação:</label>
            <textarea name="obs_teste" class="observacao"></textarea>
        </div>
    </div>

       <div class="content-button">
            <input type="submit" name="submit_teste" class="atendimento-button" value="Finalizar" onclick="progress(this)">
        </div>

        </div>
    </div>
    <!-- END TESTE -->

    <!-- ENVIANDO TODOS OS DADOS DO ATENDIMENTO PARA O PHP NO TOPO DO CÓDIGO -->
</form>

    <script src="../JAVA/ajax.js"></script>
    <script src="../JAVA/progresso.js"></script>
    <script src="../JAVA/scriptProduto.js"></script>

    </body>
</html>
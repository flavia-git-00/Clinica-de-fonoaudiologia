<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Admin Dashboard | Korsat X Parmaga</title>
    <!-- ======= Styles ====== -->
    <link rel="stylesheet" href="../CSS/style_deshboard.css">
</head>

<body>
    <!-- =============== Navigation ================ -->
    <div class="container">
        <div class="navigation">
            <ul>
                <li>
                <a href="#">
                    <span class="icon">
                        <ion-icon name="headset"></ion-icon>
                    </span>
                        <span class="title">Clinica Otovivo</span>
                 </a>
                 
                </li>

                <li>
                    <a href="#" onclick="alternar('estoque_todo')">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Painel</span>
                    </a>
                </li>

                <li>
                    <a href="#"  onclick="alternar('cliente_todo')">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">Clientes</span>
                    </a>
                </li>

                <li>
                    <a href="#" onclick="alternar('historico_todo')">
                        <span class="icon">
                            <ion-icon name="calendar-outline"></ion-icon>
                        </span>
                        <span class="title">Histórico</span>
                    </a>
                </li>

                <li>
                    <a href="#" onclick="alternar('relatorio_todo')">
                        <span class="icon">
                            <ion-icon name="cellular-outline"></ion-icon>
                        </span>
                        <span class="title">Relátorios</span>
                    </a>
                </li>

                <li>
                    <a href="index.html">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Sign Out</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- ========================= Main ==================== -->
        <div class="main">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>

                <div class="search">
                    <label>
                        <input type="text" placeholder="Search here">
                        <ion-icon name="search-outline"></ion-icon>
                    </label>
                </div>

                <div class="user">
                    <img src="../imgs/customer01.jpg" alt="">
                </div>
            </div>

            <!-- ======================= Cards ================== -->
            <div class="cardBox">
                
           

                <div class="card">
                    <div>

                <?php

                include_once("../PHP/conexao.php");

                $count_vendas = "SELECT COUNT(cod_pagamento) AS total_vendas FROM pagamento";

                $result_vendas = mysqli_query($conexao,$count_vendas);

                if ($result_vendas) {
                    $row = mysqli_fetch_assoc($result_vendas);
                    echo '<div class="numbers">';
                    echo $row['total_vendas'];
                    echo'</div>';
                }
              
                
                ?>

                      
                    <div class="cardName">Vendas</div>
                    </div>

                    <div class="iconBx">
                        <ion-icon name="cart-outline"></ion-icon>
                    </div>
                </div>

                <div class="card">
                    <div>
                        
                    <?php

                    include_once("../PHP/conexao.php");

                    $sql_total_devolucao = "SELECT COUNT(cod_devolucao) AS dev FROM devolucao";

                    $result_dev = mysqli_query($conexao,$sql_total_devolucao);

                    if($result_dev){
                        $linha = mysqli_fetch_assoc($result_dev);
                       

                        echo '<div class="numbers">';
                        echo $linha['dev'];
                        echo '</div>';
                    }

                    ?> 
                       
                        <div class="cardName">Devoluções</div>
                    </div>

                    <div class="iconBx">
                        <ion-icon name="sync-outline"></ion-icon>
                    </div>
                </div>

                
                <div class="card">
                    <div>

                    <?php

                    include_once("../PHP/conexao.php");

                    $sql_testes = "SELECT COUNT(cod_teste) AS total_testes FROM teste";

                    $result_teste = mysqli_query($conexao, $sql_testes);

                    if($result_teste){
                        $linha = mysqli_fetch_assoc($result_teste);

                        echo '<div class="numbers">';
                        echo $linha['total_testes']; // Aqui está a correção
                        echo '</div>';
                    }

                    ?> 
                        <div class="cardName">Testes</div>
                    </div>

                    <div class="iconBx">
                        <ion-icon name="swap-vertical-outline"></ion-icon>
                    </div>
                </div>

                <div class="card">
                    <div>

                    
                    <?php

                    include_once("../PHP/conexao.php");

                    $sql_total_vendas = "SELECT SUM(valor_pagamento) AS soma FROM pagamento";

                    $result_sum = mysqli_query($conexao,$sql_total_vendas);

                    if($result_sum){
                        $linha = mysqli_fetch_assoc($result_sum);
                        $valor_formatado = number_format($linha['soma'], 2, ',', '.');

                        echo '<div class="numbers">';
                        echo $valor_formatado; // Aqui está a correção
                        echo '</div>';
                    }

                    ?> 
                        
                        <div class="cardName">Ganho</div>
                    </div>

                    <div class="iconBx">
                        <ion-icon name="cash-outline"></ion-icon>
                    </div>
                </div>
            </div>

            <!-- ================ INICIO LISTA ESTOQUE ================= -->

           <div id="estoque_todo">
            <div class="details">

                <div class="recentOrders">
                    <div class="cardHeader">
                        <h2>Estoque</h2>
                        <a href="#" class="btn">View All</a>
                    </div>

                    <table>
                        <thead>
                            <tr>
                                <td>Nome</td>
                                <td>Preço</td>
                                <td>Quantidade</td>
                                <td>Status</td>
                            </tr>
                        </thead>

                        <tbody>

                        <?php

                        include_once("../PHP/conexao.php");

                        $sql_produtos = "SELECT modelo_aparelho,preco_aparelho,qtd_aparelho FROM aparelhos";

                        $result_produtos = mysqli_query($conexao,$sql_produtos);

                        if ($result_produtos && mysqli_num_rows($result_produtos) > 0) {

                            while ($linha = mysqli_fetch_assoc($result_produtos)) {
                            echo '<tr>';
                                echo '<td>' . $linha['modelo_aparelho'] . '</td>';
                                echo '<td>' . number_format($linha['preco_aparelho'], 2, ',', '.') . '</td>';
                                echo '<td>' . $linha['qtd_aparelho'] . '</td>';

                                if($linha['qtd_aparelho'] >=50){
                                    echo '<td><span class="status delivered">Abundante</span></td>';
                                }else if($linha['qtd_aparelho'] <50 && $linha['qtd_aparelho'] >=30){
                                    echo '<td><span class="status pending">Moderado</span></td>';
                                }else{
                                    echo '<td><span class="status return">Escasso</span></td>';
                                }
                            echo '</tr>';
                         }
                       }


                       $sql_baterias = "SELECT modelo_bateria,preco_bateria,qtd_bateria FROM baterias";

                        $result_baterias = mysqli_query($conexao,$sql_baterias);

                        if ($result_baterias && mysqli_num_rows($result_baterias) > 0) {

                            while ($row = mysqli_fetch_assoc($result_baterias)) {
                            echo '<tr>';
                                echo '<td>' . $row['modelo_bateria'] . '</td>';
                                echo '<td>' . number_format($row['preco_bateria'], 2, ',', '.') . '</td>';
                                echo '<td>' . $row['qtd_bateria'] . '</td>';

                                if($row['qtd_bateria'] >=50){
                                    echo '<td><span class="status delivered">Abundante</span></td>';
                                }else if($row['qtd_bateria'] <50 && $row['qtd_bateria'] >=30){
                                    echo '<td><span class="status pending">Moderado</span></td>';
                                }else{
                                    echo '<td><span class="status return">Escasso</span></td>';
                                }
                            echo '</tr>';
                         }
                       }

                       
                        ?>     

                        </tbody>
                    </table>

                </div>

                

                <div class="recentCustomers">
                    <div class="cardHeader">
                        <h2>Clientes Recentes</h2>
                    </div>

                    <table>
                        <?php

                        include_once("../PHP/conexao.php");

                        $sql_clientes = "SELECT nome_cliente,endereco FROM cliente";

                        $result_clientes = mysqli_query($conexao,$sql_clientes);

                        if ($result_clientes && mysqli_num_rows($result_clientes) > 0) {

                            while ($linha = mysqli_fetch_assoc($result_clientes)) {
                             echo '<tr>';
                                echo '<td width="60px">';
                                echo '<div class="imgBx"><img src="../imgs/customer02.jpg" alt=""></div>';
                                echo '</td>';
                                echo '<td>';
                                echo '<h4>' . $linha['nome_cliente'] . '<br> <span>' . $linha['endereco'] . '</span></h4>';
                                echo '</td>';
                             echo'</tr>';


                            }
                        }
                        ?>      
                    </table>
                   
                </div>
            </div>
        </div>
            
       
             <!-- ================= FIM LISTA ESTOQUE================ -->


               <!-- ================= INICIO HISTORICO================ -->
             
               <div id="historico_todo" style="display: none;">
             
                <div class="details">
            
                    <div class="recentOrders">
                        <div class="cardHeader">
                            <h2>Histórico</h2>
                            <form method="POST" action="" >
                            <select class="select-relatorio" name="select_cliente_his" id="">
                                <?php

                                    include_once("../PHP/conexao.php");
                                    $sql = "SELECT cod_cliente,nome_cliente FROM cliente";
                                    
                                    $result = mysqli_query($conexao,$sql); 

                                    if($result->num_rows >0){
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo '<option value="' . $row['cod_cliente'] . '">' . $row['nome_cliente'] . '</option>';
                                    }
                                    }

                                ?>
                            </select>
                           <select class="select-relatorio" name="select_transacao_his" id="select_transacao_his">
                            <option value="todos">Todos</option>
                            <option value="devolucao">Devolução</option>
                            <option value="teste">Teste</option>
                            <option value="compra">Compra</option>
                           </select>
                            <button type="submit" class="botao" name="filtrar_his">Filtrar</button>
                            </form>

                        </div>
                        <table>
                            <thead>
                                <tr>
                                    <td>Nome Cliente</td>
                                    <td>Tipo de interação</td>
                                    <td>Data da interação</td>
                                    <td>Produto</td>
                                    <td>Status de interação</td>
                                </tr>
                            </thead>
            
                            <tbody>

        <!-- FILTRO HISTORICO -->

        <?php
            include_once("../PHP/conexao.php");
            if (isset($_POST['filtrar_his'])) {

                $cliente_id = $_POST['select_cliente_his'];
                $tipo_transacao = $_POST['select_transacao_his'];

                $sql_historico_teste ="
                SELECT 
                    cliente.nome_cliente as nome, 
                    teste.cod_cliente AS 'testes',
                    teste.cod_aparelho AS 'codigo_aparelho', 
                    aparelhos.modelo_aparelho AS 'modelo_aparelho',
                    DATE_FORMAT(teste.data_retirada, '%d/%m/%Y') AS 'data',
                    'Teste' AS 'tipo_de_interacao'
                FROM 
                    cliente
                INNER JOIN 
                    teste ON cliente.cod_cliente = teste.cod_cliente
                INNER JOIN 
                    aparelhos ON aparelhos.cod_aparelho = teste.cod_aparelho
                WHERE cliente.cod_cliente='$cliente_id';
                ";

                $sql_historico_devolucao ="
                SELECT 
                    cliente.nome_cliente AS 'nome',
                    'Devolução' AS 'tipo_de_interacao',
                    DATE_FORMAT(devolucao.data_devolucao, '%d/%m/%Y') AS 'data',
                    aparelhos.modelo_aparelho AS 'modelo_aparelho'
                FROM 
                    cliente
                INNER JOIN 
                    devolucao ON cliente.cod_cliente = devolucao.cod_cliente
                INNER JOIN 
                    aparelhos ON aparelhos.cod_aparelho = devolucao.cod_aparelho
                WHERE cliente.cod_cliente='$cliente_id';
                ";

                $sql_historico_compra ="
                SELECT 
                    cliente.nome_cliente AS 'nome',
                    'Compra' AS 'tipo_de_interacao',
                    DATE_FORMAT(pagamento.data_pagamento, '%d/%m/%Y') AS 'data',
                    aparelhos.modelo_aparelho AS 'modelo_aparelho'
                FROM 
                    cliente
                INNER JOIN 
                    pagamento ON cliente.cod_cliente = pagamento.cod_cliente
                INNER JOIN 
                    aparelhos ON aparelhos.cod_aparelho = pagamento.cod_aparelho
                WHERE cliente.cod_cliente='$cliente_id';
                ";

                if($tipo_transacao == 'devolucao') {

                    $result_his_dev = mysqli_query($conexao, $sql_historico_devolucao);

                    if ($result_his_dev && mysqli_num_rows($result_his_dev) > 0) {

                        while ($linha = mysqli_fetch_assoc($result_his_dev)) {
                            echo '<tr style="background-color:#dedcdc">';
                            echo '<td>' . $linha['nome'] . '</td>';
                            echo '<td>' . $linha['tipo_de_interacao'] . '</td>';
                            echo '<td>' . $linha['data'] . '</td>';
                            echo '<td>' . $linha['modelo_aparelho'] . '</td>';
                            echo '<td><span class="status pending">Devolvido</span></td>';
                            echo '</tr>';
                        }
                    }

                } else if($tipo_transacao == 'teste') {

                    $result_his_teste = mysqli_query($conexao, $sql_historico_teste);

                    if ($result_his_teste && mysqli_num_rows($result_his_teste) > 0) {

                        while ($linha = mysqli_fetch_assoc($result_his_teste)) {
                            echo '<tr style="background-color:#dedcdc">';
                            echo '<td>' . $linha['nome'] . '</td>';
                            echo '<td>' . $linha['tipo_de_interacao'] . '</td>';
                            echo '<td>' . $linha['data'] . '</td>';
                            echo '<td>' . $linha['modelo_aparelho'] . '</td>';
                            echo '<td><span class="status inProgress">Em Teste</span></td>';
                            echo '</tr>';
                        }
                    }

                } else if($tipo_transacao == 'compra') {

                    $result_his_com = mysqli_query($conexao, $sql_historico_compra);

                    if ($result_his_com && mysqli_num_rows($result_his_com) > 0) {

                        while ($linha = mysqli_fetch_assoc($result_his_com)) {
                            echo '<tr style="background-color:#dedcdc">';
                            echo '<td>' . $linha['nome'] . '</td>';
                            echo '<td>' . $linha['tipo_de_interacao'] . '</td>';
                            echo '<td>' . $linha['data'] . '</td>';
                            echo '<td>' . $linha['modelo_aparelho'] . '</td>';
                            echo '<td><span class="status delivered">Vendido</span></td>';
                            echo '</tr>';
                        }
                    }
                }
            }
        ?>
    <!-- FIM FILTRO HISTORICO -->

                                 
                                 <!-- DADOS TABELA HISTORICO -->
                                    <?php
                                    include_once("../PHP/conexao.php");

                                    $sql_historico_teste ="SELECT 
                                    cliente.nome_cliente as nome, 
                                    teste.cod_cliente AS 'testes',
                                    teste.cod_aparelho AS 'codigo_aparelho', 
                                    aparelhos.modelo_aparelho AS 'modelo_aparelho',
                                    DATE_FORMAT(teste.data_retirada, '%d/%m/%Y') AS 'data',
                                    'Teste' AS 'tipo_de_interacao'
                                    FROM 
                                    cliente
                                    INNER JOIN 
                                    teste ON cliente.cod_cliente = teste.cod_cliente
                                    INNER JOIN 
                                    aparelhos ON aparelhos.cod_aparelho = teste.cod_aparelho;
                                    ";

                                    
                                    $sql_historico_devolucao ="SELECT 
                                    cliente.nome_cliente AS 'nome_dev',
                                    'Devolução' AS 'tipo_de_interacao_dev',
                                    DATE_FORMAT(devolucao.data_devolucao, '%d/%m/%Y') AS 'data_dev',
                                    aparelhos.modelo_aparelho AS 'modelo_aparelho_dev'
                                    FROM 
                                    cliente
                                    INNER JOIN 
                                    devolucao ON cliente.cod_cliente = devolucao.cod_cliente
                                    INNER JOIN 
                                    aparelhos ON aparelhos.cod_aparelho = devolucao.cod_aparelho;
                                    ";

                                    
                                    $sql_historico_compra ="SELECT 
                                    cliente.nome_cliente AS 'nome_com',
                                    'Compra' AS 'tipo_de_interacao_com',
                                    DATE_FORMAT(pagamento.data_pagamento, '%d/%m/%Y') AS 'data_com',
                                    aparelhos.modelo_aparelho AS 'modelo_aparelho_com'
                                    FROM 
                                        cliente
                                    INNER JOIN 
                                        pagamento ON cliente.cod_cliente = pagamento.cod_cliente
                                    INNER JOIN 
                                        aparelhos ON aparelhos.cod_aparelho = pagamento.cod_aparelho;
                                        ";

                                            

                               /**
                                * ================= INICIO HISTORICO TESTES =================
                                */


                                 $result_his_teste = mysqli_query($conexao,$sql_historico_teste);

                                    if ($result_his_teste && mysqli_num_rows($result_his_teste) > 0) {

                                        while ($linha = mysqli_fetch_assoc($result_his_teste)) {
                                            
                                        echo '<tr>';
                                            echo '<td>' . $linha['nome'] . '</td>';
                                            echo '<td>' . $linha['tipo_de_interacao'] . '</td>';
                                            echo '<td>' . $linha['data'] . '</td>';
                                            echo '<td>' . $linha['modelo_aparelho'] . '</td>';
                                            echo'<td><span class="status inProgress">Em Teste</span></td>';
   
                                        echo '</tr>';
                                    }
                                    }


                               /**
                                * ================= FIM HISTORICO TESTES =================
                                */

                                $result_his_dev = mysqli_query($conexao,$sql_historico_devolucao);

                                if ($result_his_dev && mysqli_num_rows($result_his_dev) > 0) {

                                    while ($linha = mysqli_fetch_assoc($result_his_dev)) {
                                        
                                    echo '<tr>';
                                        echo '<td>' . $linha['nome_dev'] . '</td>';
                                        echo '<td>' . $linha['tipo_de_interacao_dev'] . '</td>';
                                        echo '<td>' . $linha['data_dev'] . '</td>';
                                        echo '<td>' . $linha['modelo_aparelho_dev'] . '</td>';
                                        echo' <td><span class="status pending">Devolvido</span></td>';

                                    echo '</tr>';
                                }
                                }

                                   /**
                                * ================= FIM HISTORICO DEVOLUÇÃO =================
                                */


                                $result_his_com = mysqli_query($conexao,$sql_historico_compra);

                                if ($result_his_com && mysqli_num_rows($result_his_com) > 0) {

                                    while ($linha = mysqli_fetch_assoc($result_his_com)) {
                                        
                                    echo '<tr>';
                                        echo '<td>' . $linha['nome_com'] . '</td>';
                                        echo '<td>' . $linha['tipo_de_interacao_com'] . '</td>';
                                        echo '<td>' . $linha['data_com'] . '</td>';
                                        echo '<td>' . $linha['modelo_aparelho_com'] . '</td>';
                                        echo'<td><span class="status delivered">Vendido</span></td>';

                                    echo '</tr>';
                                }
                                }

                                    ?>
                                      <!-- FIM DADOS TABELA HISTORICO -->
                        
                            </tbody>
                        </table>
                    </div>
            
            
                        <div class="recentCustomers">
                            <div class="cardHeader">
                                <h2>Clientes Recentes</h2>
                            </div>
            
                            <table>
                          <?php

                            include_once("../PHP/conexao.php");

                            $sql_clientes = "SELECT nome_cliente,endereco FROM cliente";
                            $result_clientes = mysqli_query($conexao,$sql_clientes);

                            if ($result_clientes && mysqli_num_rows($result_clientes) > 0) {
                                while ($linha = mysqli_fetch_assoc($result_clientes)) {

                                echo '<tr>';
                                    echo '<td width="60px">';
                                    echo '<div class="imgBx"><img src="../imgs/customer02.jpg" alt=""></div>';
                                    echo '</td>';
                                    echo '<td>';
                                    echo '<h4>' . $linha['nome_cliente'] . '<br> <span>' . $linha['endereco'] . '</span></h4>';
                                    echo '</td>';
                                echo'</tr>';

                              }
                            }
                         ?>      
                            </table>
                        </div>
                    </div>
                </div>
           

             <!-- ================= FIM HISTORICO================ -->


             
                 

              <!-- ================= INICIO RELATORIO ================ -->
  <div id="relatorio_todo" style="display: none;">
             
    <div class="details">

        <div class="recentOrders">
            <div class="cardHeader">
                <h2>Relatório</h2>
                <form method="POST" action="">
                <select class="select-relatorio" name="select-relatorio" id="">
                    <option value="todos">Tudo</option>
                    <option value="entrada">Relatório de entrada </option>
                    <option value="saida">Relatório De Saída</option>
                    <option value="devolucao">Relatório de devoluções</option>
                    <option value="teste">Relatório de testes</option>
                </select>
                <input type="date" name="data_relatorio" class="data-relatorio">
                <button type="submit" class="botao" name="filtrar_relatorio">Filtrar</button>

                </form>
                
            </div>

            <table>
                <thead>
                    <tr>
                        <td>Produto</td>
                        <td>Preço</td>
                        <td>Quantidade</td>
                        <td>Data</td>
                        <td>Tipo de transação</td>
                    </tr>
                </thead>

                <tbody>

                 <!-- ================= INICIO FILTRAR RELATORIO ================ -->

        <?php
                include_once("../PHP/conexao.php");
                if (isset($_POST['filtrar_relatorio'])) {
                


                    $data_relatorio = $_POST['data_relatorio'];
                    $tipo_transacao = $_POST['select-relatorio'];

                    $sql_entrada_aparelhos = "SELECT 
                    modelo_aparelho as modelo,
                    preco_aparelho as preco,
                    qtd_aparelho as qtd,
                    DATE_FORMAT(data_aparelho, '%d/%m/%Y') AS 'data'
                    FROM aparelhos
                    WHERE data_aparelho = '$data_relatorio';
                    ";

                    $sql_teste_aparelhos = "SELECT 
                    aparelhos.modelo_aparelho as modelo,
                    aparelhos.preco_aparelho as preco,
                    teste.qtd_teste as qtd,
                    DATE_FORMAT(teste.data_retirada, '%d/%m/%Y') AS 'data'
                    FROM aparelhos
                    INNER JOIN teste ON teste.cod_aparelho = aparelhos.cod_aparelho
                    WHERE teste.data_retirada = '$data_relatorio';
                    ";

                    $sql_dev_aparelhos = "SELECT 
                    aparelhos.modelo_aparelho as modelo,
                    aparelhos.preco_aparelho as preco,
                    devolucao.qtd_devolucao as qtd,
                    DATE_FORMAT(devolucao.data_devolucao, '%d/%m/%Y') AS 'data'
                    FROM aparelhos
                    INNER JOIN devolucao ON devolucao.cod_aparelho = aparelhos.cod_aparelho
                    WHERE devolucao.data_devolucao = '$data_relatorio';
                    ";

                    $sql_saida_aparelhos = "SELECT 
                    aparelhos.modelo_aparelho as modelo,
                    aparelhos.preco_aparelho as preco,
                    pagamento.qtd_pagamento as qtd,
                    DATE_FORMAT(pagamento.data_pagamento, '%d/%m/%Y') AS 'data'
                    FROM aparelhos
                    INNER JOIN pagamento ON pagamento.cod_aparelho = aparelhos.cod_aparelho
                    WHERE pagamento.data_pagamento = '$data_relatorio';
                    ";

                    if($tipo_transacao == 'entrada') {

                        $result_relatorio_entrada = mysqli_query($conexao, $sql_entrada_aparelhos);

                        if ($result_relatorio_entrada && mysqli_num_rows($result_relatorio_entrada) > 0) {

                            while ($linha = mysqli_fetch_assoc($result_relatorio_entrada)) {
                                echo '<tr style="background-color:#dedcdc">';
                                echo '<td>' . $linha['modelo'] . '</td>';
                                echo '<td>' . $linha['preco'] . '</td>';
                                echo '<td>' . $linha['qtd'] . '</td>';
                                echo '<td>' . $linha['data'] . '</td>';
                                echo'<td><span class="status delivered">Entrada Estoque</span></td>';
                                echo '</tr>';
                            }
                        }

                    } else if($tipo_transacao == 'saida') {

                        $result_his_saida = mysqli_query($conexao, $sql_saida_aparelhos);

                        if ($result_his_saida && mysqli_num_rows($result_his_saida) > 0) {

                            while ($linha = mysqli_fetch_assoc($result_his_saida)) {
                                echo '<tr style="background-color:#dedcdc">';
                                echo '<td>' . $linha['modelo'] . '</td>';
                                echo '<td>' . $linha['preco'] . '</td>';
                                echo '<td>' . $linha['qtd'] . '</td>';
                                echo '<td>' . $linha['data'] . '</td>';
                                echo'<td><span class="status return">Saida Venda</span></td>';
                                echo '</tr>';
                            }
                        }

                    } else if($tipo_transacao == 'devolucao') {

                        $result_his_dev = mysqli_query($conexao, $sql_dev_aparelhos);

                        if ($result_his_dev && mysqli_num_rows($result_his_dev) > 0) {

                            while ($linha = mysqli_fetch_assoc($result_his_dev)) {
                                echo '<tr style="background-color:#dedcdc">';
                                echo '<td>' . $linha['modelo'] . '</td>';
                                echo '<td>' . $linha['preco'] . '</td>';
                                echo '<td>' . $linha['qtd'] . '</td>';
                                echo '<td>' . $linha['data'] . '</td>';
                                echo'<td><span class="status pending">Devolução Estoque</span></td>';
                                echo '</tr>';
                            }
                        }

                    } else if($tipo_transacao == 'teste') {

                        $result_his_teste = mysqli_query($conexao, $sql_teste_aparelhos);

                        if ($result_his_teste && mysqli_num_rows($result_his_teste) > 0) {

                            while ($linha = mysqli_fetch_assoc($result_his_teste)) {
                                echo '<tr style="background-color:#dedcdc">';
                                echo '<td>' . $linha['modelo'] . '</td>';
                                echo '<td>' . $linha['preco'] . '</td>';
                                echo '<td>' . $linha['qtd'] . '</td>';
                                echo '<td>' . $linha['data'] . '</td>';
                                echo'<td><span class="status inProgress"> Saída Teste</span></td>';
                                echo '</tr>';
                            }
                        }
                    }
                }
?>
 <!-- ================= FIM FILTRAR RELATORIO ================ -->

              



                <?php
                
                                    include_once("../PHP/conexao.php");    

                                    $sql_entrada_aparelhos ="SELECT 
                                    modelo_aparelho as modelo,preco_aparelho as preco,
                                    qtd_aparelho as qtd,
                                    DATE_FORMAT(data_aparelho, '%d/%m/%Y') AS 'data'
                                    FROM aparelhos;
                                    ";

                                    $sql_teste_aparelhos ="SELECT 
                                    aparelhos.modelo_aparelho as modelo,
                                    aparelhos.preco_aparelho as preco,
                                    teste.qtd_teste as qtd,
                                    DATE_FORMAT(teste.data_retirada, '%d/%m/%Y') AS 'data'
                                    FROM aparelhos
                                    INNER JOIN teste ON teste.cod_aparelho = aparelhos.cod_aparelho;
                                    ";

                                                                                                    
                                    

                                    $sql_dev_aparelhos ="SELECT 
                                    aparelhos.modelo_aparelho as modelo,
                                    aparelhos.preco_aparelho as preco,
                                    devolucao.qtd_devolucao as qtd,
                                    DATE_FORMAT(devolucao.data_devolucao, '%d/%m/%Y') AS 'data'
                                    FROM aparelhos
                                    INNER JOIN devolucao ON devolucao.cod_aparelho = aparelhos.cod_aparelho;
                                    ";

                                                                        
                                  

                                    $sql_saida_aparelhos ="SELECT 
                                    aparelhos.modelo_aparelho as modelo,
                                    aparelhos.preco_aparelho as preco,
                                    pagamento.qtd_pagamento as qtd,
                                    DATE_FORMAT(pagamento.data_pagamento, '%d/%m/%Y') AS 'data'
                                    FROM aparelhos
                                    INNER JOIN pagamento ON pagamento.cod_aparelho = aparelhos.cod_aparelho;
                                    ";


                               /**
                                * ================= INICIO HISTORICO TESTES =================
                                */

                                $result_teste_relatorio = mysqli_query($conexao,$sql_teste_aparelhos);

                                if ($result_teste_relatorio && mysqli_num_rows($result_teste_relatorio) > 0) {

                                    while ($linha = mysqli_fetch_assoc($result_teste_relatorio)) {
                                        
                                    echo '<tr>';
                                        echo '<td>' . $linha['modelo'] . '</td>';
                                        echo '<td>' . $linha['preco'] . '</td>';
                                        echo '<td>' . $linha['qtd'] . '</td>';
                                        echo '<td>' . $linha['data'] . '</td>';
                                        echo'<td><span class="status inProgress"> Saída Teste</span></td>';

                                    echo '</tr>';
                                }
                                }

                                $result_saida = mysqli_query($conexao,$sql_saida_aparelhos);

                                if ($result_saida && mysqli_num_rows($result_saida) > 0) {

                                    while ($linha = mysqli_fetch_assoc($result_saida)) {
                                        
                                    echo '<tr>';
                                        echo '<td>' . $linha['modelo'] . '</td>';
                                        echo '<td>' . $linha['preco'] . '</td>';
                                        echo '<td>' . $linha['qtd'] . '</td>';
                                        echo '<td>' . $linha['data'] . '</td>';
                                        echo'<td><span class="status return">Saida Venda</span></td>';

                                    echo '</tr>';
                                }
                                }

                                $result_dev_aparelhos = mysqli_query($conexao,$sql_dev_aparelhos);

                                if ($result_dev_aparelhos && mysqli_num_rows($result_dev_aparelhos) > 0) {

                                    while ($linha = mysqli_fetch_assoc($result_dev_aparelhos)) {
                                        
                                    echo '<tr>';
                                        echo '<td>' . $linha['modelo'] . '</td>';
                                        echo '<td>' . $linha['preco'] . '</td>';
                                        echo '<td>' . $linha['qtd'] . '</td>';
                                        echo '<td>' . $linha['data'] . '</td>';
                                        echo'<td><span class="status pending">Devolução Estoque</span></td>';

                                    echo '</tr>';
                                }
                                }
                               




                                 $result_aparelhos = mysqli_query($conexao,$sql_entrada_aparelhos);

                                    if ($result_aparelhos && mysqli_num_rows($result_aparelhos) > 0) {

                                        while ($linha = mysqli_fetch_assoc($result_aparelhos)) {
                                            
                                        echo '<tr>';
                                            echo '<td>' . $linha['modelo'] . '</td>';
                                            echo '<td>' . $linha['preco'] . '</td>';
                                            echo '<td>' . $linha['qtd'] . '</td>';
                                            echo '<td>' . $linha['data'] . '</td>';
                                            echo'<td><span class="status delivered">Entrada Estoque</span></td>';
   
                                        echo '</tr>';
                                    }
                                    }



                                    ?>
                </tbody>
            </table>
        </div>

            <div class="recentCustomers">
                <div class="cardHeader">
                    <h2>Clientes Recentes</h2>
                </div>

                <table>
                <?php

                include_once("../PHP/conexao.php");

                $sql_clientes = "SELECT nome_cliente,endereco FROM cliente";
                $result_clientes = mysqli_query($conexao,$sql_clientes);

                if ($result_clientes && mysqli_num_rows($result_clientes) > 0) {
                    while ($linha = mysqli_fetch_assoc($result_clientes)) {

                    echo '<tr>';
                        echo '<td width="60px">';
                        echo '<div class="imgBx"><img src="../imgs/customer02.jpg" alt=""></div>';
                        echo '</td>';
                        echo '<td>';
                        echo '<h4>' . $linha['nome_cliente'] . '<br> <span>' . $linha['endereco'] . '</span></h4>';
                        echo '</td>';
                    echo'</tr>';

                }
                }
                ?>      
                </table>
        </div>
        </div>
        </div>

               <!-- ================= FIM RELATORIO================ -->
               <div id="cliente_todo" style="display: none;">
    <!-- ================= container Clientes Parte 1 ================ -->

    <div class="details">

        <div class="recentOrders">
            <div class="cardHeader">
                <h2>Visualizar clientes</h2>
                <a href="deshboard.php" class="btn">View All</a>
            </div>

            <table>
                <thead>
                    <tr>
                        <td>Nome</td>
                        <td>Email</td>
                        <td>Telefone</td>
                        <td>Dados Pessoais</td>
                        
                    </tr>
                </thead>

                <tbody>
                    <?php
                    include_once("../PHP/conexao.php");

                    $sql_clientes = "SELECT cod_cliente, nome_cliente, telefone, email FROM cliente";
                    $result_clientes = mysqli_query($conexao, $sql_clientes);

                    if ($result_clientes && mysqli_num_rows($result_clientes) > 0) {
                        while ($linha = mysqli_fetch_assoc($result_clientes)) {
                            echo '<form method="POST" action="">';
                            echo '<tr>';
                            echo '<input type="hidden" name="cod_cliente" value="' . $linha['cod_cliente'] . '">';
                            echo '<td>' . $linha['nome_cliente'] . '</td>';
                            echo '<td>' . $linha['email'] . '</td>';
                            echo '<td>' . $linha['telefone'] . '</td>';
                            echo '<td><button type="submit" class="botao" name="visualizar_cliente">Visualizar</button></td>';
                            echo '</tr>';
                            echo '</form>';
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <!-- ================= FIM Clientes Parte 1 ================ -->


        <!-- ================= INICIO Clientes Parte 2 ================ -->

        <div class="dados-pessoais">
            <?php
            include_once("../PHP/conexao.php");

            if (isset($_POST['visualizar_cliente'])) {
                $cod_cliente = $_POST['cod_cliente'];
                $sql_clientes = "SELECT nome_cliente, data_nas, genero, cpf, email, telefone, endereco, TIMESTAMPDIFF(YEAR, data_nas, CURDATE()) AS idade FROM cliente WHERE cod_cliente='$cod_cliente'";
                $result_clientes = mysqli_query($conexao, $sql_clientes);

                if ($result_clientes && mysqli_num_rows($result_clientes) > 0) {
                    while ($linha = mysqli_fetch_assoc($result_clientes)) {
                        echo '<div class="align-center">';
                        echo '<h1>' . $linha['nome_cliente'] . '</h1>';
                        echo '</div>';

                        echo '<div class="imgDados"><img src="../imgs/customer02.jpg" alt="Foto de Marcelo Rezende"></div>';

                        echo '<div class="texto">';
                        echo '<p class="dados_cliente"><strong>Idade:</strong> ' . $linha['idade'] . '</p>';
                        echo '<p class="dados_cliente"><strong>Gênero:</strong> ' . $linha['genero'] . '</p>';
                        echo '<p class="dados_cliente"><strong>CPF:</strong> ' . $linha['cpf'] . '</p>';
                        echo '<p class="dados_cliente"><strong>Email:</strong> ' . $linha['email'] . '</p>';
                        echo '<p class="dados_cliente"><strong>Telefone:</strong> ' . $linha['telefone'] . '</p>';
                        echo '<p class="dados_cliente"><strong>Endereço:</strong> ' . $linha['endereco'] . '</p>';
                        echo '</div>';
                    }
                }
            } else {
                echo '<div class="align-center">';
                echo '<h1 style="color:gray">CAMPO VAZIO</h1>';
                echo '</div>';
            }
            ?>
        </div>

        <!-- ================= FIM  Clientes Parte 2 ================ -->

    <!-- =========== Scripts =========  -->
    <script src="../JAVA/deshboard.js"></script>

    <!-- ====== ionicons ======= -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>

</html>
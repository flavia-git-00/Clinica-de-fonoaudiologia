<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <title>Atualizar Paciente</title>
    <link rel="stylesheet" href="../CSS/atendimento.css">
    <style>
        .icons {
            position: absolute; /* Define o posicionamento absoluto */
            top: 10px; /* Define a distância do topo */
            left: 10px; /* Define a distância da esquerda */
            color: #ffffff;
            text-decoration: none;
            font-size: 40px; /* Define o tamanho do ícone */
            cursor: pointer;
            }
            .bi-arrow-return-left{
            color: #ffffff;
            }
            .bi-arrow-return-left:hover{
            /*cor de fundo quando  o mouse passa por cima*/
            background-color: #3a9d7d;
            color:#287c62;
            }
    </style>
</head>
<body>

        <div class = "icons" >
                <a href="index.html" class="back-button"><i class="bi bi-arrow-return-left"></i> </a>
        </div>

<div class="br"></div>
<div class="br"></div>
<div class="br"></div>
<div class="br"></div>


<form action="atualizar_paciente.php" method="post">
    <!-- ENVIA O CODIGO DO CLIENTE PELO NAME DO SELECT -->
        <div class="container">
            <div class="box">
                  
            <h1>Selecione o Paciente</h1>
                
            <label for="Paciente" class="paciente-label">Nome completo:</label>
            <select class="paciente-select" name="paciente-select" id="">

            <?php
                include_once("../PHP/conexao.php");

                $sql = "SELECT cod_cliente,nome_cliente FROM cliente";
                $result = mysqli_query($conexao,$sql); 

                if($result->num_rows >0){

                while ($row = mysqli_fetch_assoc($result)) {

                    echo '<option value="' . $row['cod_cliente'] . '">' . $row['nome_cliente'] . '</option>';
              }
            }
          ?>
            
         </select>
                <button type="submit" class="paciente-button">Próximo</button>
            </div>
        </div>
    </form>
    <!-- END -->

    </body>
</html>

              


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atualizar Paciente</title>
<style>
    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Poppins",sans-serif;
        
        
    }
    .container_poput{
        width: 100%;
        height: 100vh;
        background-color:#1f553e;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .btn{
        padding: 10px 60px;
        background-color: #fff;
        border: 0;
        outline: none;
        cursor: pointer;
        font-size: 22px;
        font-weight: 500;
        border-radius: 30px;
    }
    .poput{
        width: 400px;
        background: #fff;
        border-radius: 6px;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%,-50%) scale(1);
        text-align: center;
        padding: 0 30px 30px;
        color: #333;
        visibility: visible;
        transition: transform 0.4s, top 0.4s;
    }

    .poput img{
        width: 100px;
        margin-top: -50px;
        border-radius: 50%;
        box-shadow: 0 2px 5px rgba(0, 0,0, 0.2);
    }
    .poput h2{
        font-size: 38px;
        font-weight: 500;
        margin: 30px 0 10px;

    }
    .poput button{
        width: 100%;
        margin-top: 50px;
        padding: 10px 0;
        background-color:#6fd649 ;
        color: #fff;
        border: 0;
        outline: none;
        font-size: 18px;
        border-radius: 4px;
        cursor: pointer;
        box-shadow: 0 2px 5px rgba(0, 0,0, 0.2);
    }
    .poput button:hover{
        background-color:#49dc13 ;
    }
    /* FIM CODIGO POPUT */
</style>

</head>
<body>
    
<?php

   include_once("../PHP/conexao.php");

        if (isset($_POST['atualizar'])) {
        // Obter os dados do formulário
        $cod_cliente=$_POST['cod_cliente'];
        $nome_cliente = $_POST['nome_cliente'];
        $data_nas = $_POST['data_nas'];
        $telefone=$_POST['celular'];
        $email = $_POST['email'];
        $cpf = $_POST['cpf'];
        $endereco = $_POST['endereco'];
        $genero = $_POST['genero'];


        // SQL para atualizar os dados do cliente
        $sql = "UPDATE cliente SET 
                nome_cliente='$nome_cliente',  
                email='$email', 
                telefone='$telefone', 
                data_nas='$data_nas', 
                cpf='$cpf', 
                endereco='$endereco',
                genero='$genero'
                WHERE cod_cliente ='$cod_cliente'";

                $result= mysqli_query($conexao,$sql);

        if ($result === TRUE) {
            echo '<div class="container_poput">';
            echo '<div class="poput" id="poput">';
            echo '    <img src="../imgs/poput.png" alt="">';
            echo '    <h2>Paciente Atualizado!</h2>';
            echo '    <p>Os dados já foram modificados no banco.</p>';
            echo '    <button type="button" onclick="closePoput()">OK</button>';
            echo '</div>';
            echo '</div>';

            echo '<script>
                function closePoput() {
                    let poput = document.getElementById("poput");
                    setTimeout(function() {
                        window.location.href = "atualizarC.php";
                    }, 500); // Atraso de 500ms para permitir que a animação de fechamento ocorra
                }
            </script>';
            exit();
        } else {
            echo "Erro ao atualizar os dados: " . $conexao->error;
            exit();
        }
        }
?>
</body>
</html>


<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/cad_cliente.css">
    <title>Fazer Cadastro</title>

    <script>
        function formatarCPF(cpf) {
            cpf = cpf.replace(/\D/g, ''); // Remove tudo que não for dígito
            cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2'); // Coloca ponto após os primeiros 3 dígitos
            cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2'); // Coloca ponto após os segundos 3 dígitos
            cpf = cpf.replace(/(\d{3})(\d{1,2})$/, '$1-$2'); // Coloca hífen antes dos últimos 2 dígitos
            return cpf;
        }

        function formatarTelefone(telefone) {
            // Remove tudo que não for dígito
            telefone = telefone.replace(/\D/g, '');
            // Limita o número de dígitos a 13 (incluindo o DDD)
            if (telefone.length > 13) {
                telefone = telefone.slice(0, 13);
            }
            // Formatação personalizada para número de celular com DDD (XX) XXXXX-XXXX
            telefone = telefone.replace(/^(\d{2})(\d{5})(\d{4})$/, '($1) $2-$3');
            return telefone;
        }

    </script>

</head>

<body>

   
<div class="container">
        
    <div class="form">
            <form action="../PHP/update_cliente.php" method="post">


            <div class="form-header">
                    <div class="title">
                        <h1>Atualizar-se</h1>
                    </div>
                    <div class="login-button">
                        <button><a href="index.html">Voltar</a></button>
                    </div>
                </div>

            <?php
                     include_once("../PHP/conexao.php");

                     if ($_SERVER["REQUEST_METHOD"] == "POST") {

                    $cod_cliente = $_POST['paciente-select'];
    
                     
                     $sql = "SELECT cod_cliente,nome_cliente,email,telefone,data_nas,
                     cpf,endereco,genero FROM cliente 
                     WHERE cod_cliente ='$cod_cliente'";

                     $result = mysqli_query($conexao,$sql); 
     
                     if($result->num_rows >0){
     
                     while ($row = mysqli_fetch_assoc($result)) {
                      echo'<p>'.$row['cod_cliente'].'</p>';
                      echo'<p>'.$row['nome_cliente'].'</p>';
                      echo'<p>'.$row['email'].'</p>';
                      echo'<p>'.$row['telefone'].'</p>';
                      echo'<p>'.$row['data_nas'].'</p>';
                      echo'<p>'.$row['cpf'].'</p>';
                      echo'<p>'.$row['endereco'].'</p>';
                      echo'<p>'.$row['genero'].'</p>';


                    }
                  }
                }
            ?>


               

                <input type="text" name="cod_cliente">

                <div class="input-group">
                    <div class="input-box">
                        <label for="nome_cliente">Nome Completo:</label>
                        <input id="firstname" name="nome_cliente" type="text"  placeholder="Digite seu nome completo" required>
                    </div>

                  
                    <div class="input-box">
                        <label for="email">E-mail</label>
                        <input id="email" name="email" type="email"  placeholder="Digite seu melhor email" required>

                      
                        </div>

                    <div class="input-box">
                        <label for="celular">Celular</label>
                        <input id="phone" name="celular" type="text"  placeholder="(xx)xxxxx-xxxx" required>
                    </div>

                    <div class="input-box">
                        <label for="data_nas">Data de nascimento</label>
                        <input id="birthdate" name="data_nas" type="date"  required>
                    </div>

                    <div class="input-box">
                        <label for="cpf">CPF</label>
                        <input id="cpf" name="cpf" type="text"  placeholder="000.000.000-00" required>
                    </div>

                  

                    <div class="input-box">
                        <label for="endereco">Endereço</label>
                        <input id="address" name="endereco" type="text"  placeholder="Digite seu endereço" required>
                    </div>

                </div>

            <div class="gender-inputs">
                    <div class="gender-title">
                        <h6>Gênero</h6>
                    </div>

                    <div class="gender-group">
                        <div class="gender-input">
                            <input id="female" value="Feminino" type="radio" name="genero">
                            <label for="female">Feminino</label>
                        </div>

                        <div class="gender-input">
                            <input id="male" value="Masculino" type="radio" name="genero">
                            <label for="male">Masculino</label>
                        </div>

                        <div class="gender-input">
                            <input id="others" value="Outro" type="radio" name="genero">
                             
                            <label for="others">Outros</label>
                        </div>

                    <div class="gender-input">
                        <input id="none" value="Prefiro não dizer" type="radio" name="genero">
                        <label for="none">Prefiro não dizer</label>
                    </div>
        </div>

                <div class="continue-button">
                    <button value="atualizar" type="submit">Atualizar </button>
                </div>
            </form>
        </div>
    </div>
 
        
</body>

</html>
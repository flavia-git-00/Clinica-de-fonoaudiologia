<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/cad_cliente.css">
    <title>Atualizar-se</title>

    <script>
        function formatarCPF(cpf) {
            cpf = cpf.replace(/\D/g, ''); // Remove tudo que não for dígito
            cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2'); // Coloca ponto após os primeiros 3 dígitos
            cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2'); // Coloca ponto após os segundos 3 dígitos
            cpf = cpf.replace(/(\d{3})(\d{1,2})$/, '$1-$2'); // Coloca hífen antes dos últimos 2 dígitos
            return cpf;
        }

        function formatarTelefone(telefone) {
            // Remove tudo que não for dígito
            telefone = telefone.replace(/\D/g, '');
            // Limita o número de dígitos a 13 (incluindo o DDD)
            if (telefone.length > 13) {
                telefone = telefone.slice(0, 13);
            }
            // Formatação personalizada para número de celular com DDD (XX) XXXXX-XXXX
            telefone = telefone.replace(/^(\d{2})(\d{5})(\d{4})$/, '($1) $2-$3');
            return telefone;
        }
    </script>

</head>

<body>
<!-- ESTOU PEGANDO O CODIGO DO CLIENTE SELECIONADO NO OPTION  -->
<?php
                     include_once("../PHP/conexao.php");

                     if ($_SERVER["REQUEST_METHOD"] == "POST") {

                    $cod_cliente = $_POST['paciente-select'];
    
                    //  Consulta retornando os dados do cliente selecionado
                     $sql = "SELECT cod_cliente,nome_cliente,email,telefone,data_nas,
                     cpf,endereco,genero FROM cliente 
                     WHERE cod_cliente ='$cod_cliente'";

                     $result = mysqli_query($conexao,$sql); 
     
                     if($result->num_rows >0){
     
                     while ($row = mysqli_fetch_assoc($result)) {
                    
                        echo '<div class="container">';

                        echo '    <div class="form">';
                        // ENVIANDO OS DADOS PARA OUTRO ARQUIVO PHP QUE ATUALIZA DOS DADOS NO BANCO
                        echo '        <form action="../PHP/update_cliente.php" method="post">';
                        
                        // Cabeçalho do formulário
                        echo '            <div class="form-header">';
                        echo '                <div class="title">';
                        echo '                    <h1>Atualizar-se</h1>';
                        echo '                </div>';
                        echo '                <div class="login-button">';
                        echo '                    <button><a href="index.html">Voltar</a></button>';
                        echo '                </div>';
                        echo '            </div>';
                        
                        // Grupo de inputs
                        echo '            <div class="input-group">';
                        
                        echo '<input  type="hidden" name="cod_cliente" value=" '.$row['cod_cliente'].'" placeholder="Digite seu nome completo" required>';
                        // Nome Completo
                        echo '                <div class="input-box">';
                        echo '                    <label for="nome_cliente">Nome Completo:</label>';
                        echo '                    <input id="firstname" type="text" name="nome_cliente" value=" '.$row['nome_cliente'].'" placeholder="Digite seu nome completo" required>';
                        echo '                </div>';
                        
                        // E-mail
                        echo '                <div class="input-box">';
                        echo '                    <label for="email">E-mail</label>';
                        echo '                    <input id="email"  value=" '.$row['email'].'" type="email" name="email" placeholder="Digite seu melhor email" required>';
                        echo '                </div>';
                        
                        // Celular
                        echo '                <div class="input-box">';
                        echo '                    <label for="celular">Celular</label>';
                        echo '                    <input id="number1" type="tel"  value=" '.$row['telefone'].'" name="celular" placeholder="(xx)xxxxx-xxxx" oninput="this.value = formatarTelefone(this.value)" maxlength="14" required>';
                        echo '                </div>';
                        
                        // Data de nascimento
                        echo '                <div class="input-box">';
                        echo '                    <label for="data_nas">Data de nascimento</label>';
                        echo '                    <input type="date" value="' . $row['data_nas'] . '" name="data_nas" required>';
                        echo '                </div>';
                        
                        // CPF
                        echo '                <div class="input-box">';
                        echo '                    <label for="cpf">CPF</label>';
                        echo '                    <input id="number" type="text" name="cpf"  value=" '.$row['cpf'].'" oninput="this.value = formatarCPF(this.value)" pattern="\d{3}\.\d{3}\.\d{3}-\d{2}" placeholder="000.000.000-00" maxlength="14" required>';
                        echo '                </div>';
                        
                        // Endereço
                        echo '                <div class="input-box">';
                        echo '                    <label for="endereco">Endereço</label>';
                        echo '                    <input id="endereco" type="text"  value=" '.$row['endereco'].'" name="endereco" placeholder="Digite seu endereço" required>';
                        echo '                </div>';
                        
                        echo '            </div>'; // Fechamento do grupo de inputs
                        
                        // Gênero
                        echo '            <div class="gender-inputs">';
                        echo '                <div class="gender-title">';
                        echo '                    <h6>Gênero</h6>';
                        echo '                </div>';
                        echo '                <div class="gender-group">';
                        echo '                    <div class="gender-input">';
                        echo '                        <input id="female" value="Feminino" type="radio" name="genero" ' . ($row['genero'] == 'Feminino' ? 'checked' : '') . '>';
                        echo '                        <label for="female">Feminino</label>';
                        echo '                    </div>';
                        echo '                    <div class="gender-input">';
                        echo '                        <input id="male" value="Masculino" type="radio" name="genero" ' . ($row['genero'] == 'Masculino' ? 'checked' : '') . '>';
                        echo '                        <label for="male">Masculino</label>';
                        echo '                    </div>';
                        echo '                    <div class="gender-input">';
                        echo '                        <input id="others" value="Outro" type="radio" name="genero" ' . ($row['genero'] == 'Outros' ? 'checked' : '') . '>';
                        echo '                        <label for="others">Outros</label>';
                        echo '                    </div>';
                        echo '                    <div class="gender-input">';
                        echo '                        <input id="none" value="Prefiro não dizer" type="radio" name="genero" ' . ($row['genero'] == 'Prefiro não dizer' ? 'checked' : '') . '>';
                        echo '                        <label for="none">Prefiro não dizer</label>';
                        echo '                    </div>';
                        echo '                </div>';
                        echo '            </div>';
                        
                        // Botão de envio
                    echo '<div class="continue-button">';
                        echo'<button type "submit">';
                                echo'atualizar';
                        echo'</button>';  
                    echo ' </div>';
                        
                        echo '        </form>';
                        echo '    </div>';
                        echo '</div>';

                    }
                  }
                }

               

            ?>
    <!-- END -->

   
</body>

</html>